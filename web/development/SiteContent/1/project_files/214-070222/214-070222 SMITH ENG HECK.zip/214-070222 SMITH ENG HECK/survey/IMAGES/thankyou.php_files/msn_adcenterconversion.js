function msn_adcenter_conversion()
{
   var convprot = 'http:';
   var convdomainid = 0;
   var convprice = 0;
   var convsku = 0;
   var url = "";

   if (location.protocol.toLowerCase() == 'https:') 
        convprot = 'https:';
   
   if (window.msn_adcenterconversion_domainid)
        convdomainid = window.msn_adcenterconversion_domainid;

   if(window.msn_adcenterconversion_sku)
        convsku = window.msn_adcenterconversion_sku;

   if(window.msn_adcenterconversion_cp)
        convprice = window.msn_adcenterconversion_cp;    
    
   url = convprot + "//";

   if(convdomainid)
        url = url + convdomainid + ".r.msn.com/?type=1&cp=";
   else
        url = url + "r.msn.com/?type=1&cp=";

   url = url + convprice + "&sku=" + convsku;

   document.write('<img border=0 height=1 width=1 src="'
                  + url + '">');

}


msn_adcenter_conversion();