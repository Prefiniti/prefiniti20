CF_FRACTION v. 1.0
(c) 1999 by Michel Vuijlsteke, Netpoint NV (michel@netpoint.be)

Converts decimals to fractions. See http://www.zog.org/cf_fraction.cfm for details.